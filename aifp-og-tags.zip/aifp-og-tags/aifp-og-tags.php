<?php
/**
 * Plugin Name: AIFP Open Graph Tags
 * Plugin URI: https://aitoolsforpros.com
 * Description: Adds og:title, og:description, og:url, og:image, canonical, and Twitter Card meta tags for all AIFP custom post types.
 * Version: 1.0.0
 * Author: Rich Migliorisi
 */
defined('ABSPATH') || exit;

add_action('wp_head', function () {
    if (!is_singular()) return;
    $post_id   = get_the_ID();
    $post_type = get_post_type($post_id);
    $raw       = get_post_field('post_content', $post_id);
    $data      = $raw ? (json_decode($raw, true) ?: []) : [];
    $site_name = 'AI Tools for Pros';
    $img       = 'https://aitoolsforpros.com/wp-content/uploads/2025/11/cropped-aitoolsforpros.png';
    $url       = get_permalink($post_id);

    if ($post_type === 'tool_review') {
        $name  = $data['tool_name'] ?? get_the_title();
        $title = $name . ' for Professionals: An Honest Review (' . date('Y') . ')';
        $desc  = wp_strip_all_tags($data['definition_sentence'] ?? $data['positioning_statement'] ?? '');
        if (!$desc) $desc = 'An independent, in-depth review of ' . $name . ' for professional use.';

    } elseif ($post_type === 'cross_reference') {
        $tid  = (int) get_post_meta($post_id, 'linked_tool', true);
        $pid  = (int) get_post_meta($post_id, 'linked_profession', true);
        $td   = $tid ? (json_decode(get_post_field('post_content', $tid), true) ?: []) : [];
        $pd   = $pid ? (json_decode(get_post_field('post_content', $pid), true) ?: []) : [];
        $name = $td['tool_name'] ?? '';
        $prof = $pd['profession_name'] ?? '';
        $title = $data['title'] ?? ($name . ' for ' . $prof . ': Practical AI Guide');
        $desc  = wp_strip_all_tags($data['subtitle'] ?? '');
        if (!$desc) $desc = 'How ' . $name . ' helps ' . $prof . ' work smarter.';

    } elseif ($post_type === 'profession_hub') {
        $prof  = $data['profession_name'] ?? get_the_title();
        $title = 'Best AI Tools for ' . $prof . ' (2026 Guide)';
        $desc  = wp_strip_all_tags($data['intro_text'] ?? $data['subtitle'] ?? '');
        if (!$desc) $desc = 'The top AI tools for ' . $prof . ', reviewed and ranked.';

    } else {
        return;
    }

    $desc = mb_strimwidth(wp_strip_all_tags($desc), 0, 160, '...');
    echo '<meta name="description" content="' . esc_attr($desc) . '">\n';
    echo '<link rel="canonical" href="' . esc_url($url) . '">\n';
    echo '<meta property="og:title" content="' . esc_attr($title) . '">\n';
    echo '<meta property="og:description" content="' . esc_attr($desc) . '">\n';
    echo '<meta property="og:url" content="' . esc_url($url) . '">\n';
    echo '<meta property="og:type" content="article">\n';
    echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '">\n';
    echo '<meta property="og:image" content="' . esc_url($img) . '">\n';
    echo '<meta name="twitter:card" content="summary_large_image">\n';
    echo '<meta name="twitter:title" content="' . esc_attr($title) . '">\n';
    echo '<meta name="twitter:description" content="' . esc_attr($desc) . '">\n';
    echo '<meta name="twitter:image" content="' . esc_url($img) . '">\n';
}, 5);

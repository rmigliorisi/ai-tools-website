<?php
/**
 * Template Part: What Most Reviews Miss
 * Matches the static site layout: insight cards + banner + one-thing paragraphs.
 *
 * @package AIFP
 */

$post_id  = $post_id ?? get_the_ID();
$data     = aifp_get_data($post_id);
$insights = $data['reviews_miss'] ?? [];
$banner   = $data['insight_banner'] ?? '';
$extras   = $data['reviews_miss_extras'] ?? '';

if (empty($insights) && empty($banner)) return;
?>

<h2 style="font-size:26px;font-weight:700;color:#111111;margin:0 0 20px;">What Most Reviews Miss</h2>

<?php if (!empty($insights)) : ?>
<div style="display:flex;flex-direction:column;gap:20px;margin-bottom:28px;">
  <?php foreach ($insights as $insight) : ?>
  <div style="background:#f9fafb;border-radius:10px;padding:20px 24px;">
    <p style="font-size:14px;color:#444444;line-height:1.75;margin:0;"><?php echo wp_kses_post($insight['insight_body'] ?? ''); ?></p>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($banner) : ?>
<p style="font-size:15px;font-weight:600;color:#111111;background:#fffbeb;border-left:3px solid #f59e0b;padding:14px 18px;border-radius:0 8px 8px 0;margin:0 0 16px;"><?php echo esc_html($banner); ?></p>
<?php endif; ?>

<?php if ($extras) : ?>
<div style="font-size:14px;color:#444444;line-height:1.75;"><?php echo wp_kses_post($extras); ?></div>
<?php endif; ?>
